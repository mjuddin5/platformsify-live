import Head from 'next/head';

export default function Home() {
  return (
    <>
      <Head>
        <title>Platformsify - Build Smarter</title>
        <meta name="description" content="Your platform for scalable tools and growth" />
      </Head>
      <main className="text-center p-10">
        <h1 className="text-4xl font-bold mb-4">🚀 Platformsify</h1>
        <p className="mb-2">Build, scale, and launch your platform with ease.</p>
        <p>
          Visit our live demo:{' '}
          <a href="https://platformsify.vercel.app" className="text-blue-600 underline">
            platformsify.vercel.app
          </a>
        </p>

        {/* Features Section */}
        <section className="mt-12 grid md:grid-cols-3 gap-6 text-left">
          <div className="bg-white p-6 shadow rounded">
            <h2 className="text-xl font-semibold mb-2">⚙️ Modular Architecture</h2>
            <p>Scale without complexity. Build with clean, maintainable components.</p>
          </div>
          <div className="bg-white p-6 shadow rounded">
            <h2 className="text-xl font-semibold mb-2">🚀 Performance First</h2>
            <p>Optimized for speed using Next.js and modern deployment tools like Vercel.</p>
          </div>
          <div className="bg-white p-6 shadow rounded">
            <h2 className="text-xl font-semibold mb-2">🛠 Developer Friendly</h2>
            <p>Built with Tailwind CSS, easy to extend, and ready for dynamic integrations.</p>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="my-16 max-w-4xl mx-auto px-6">
          <h2 className="text-3xl font-semibold mb-8 text-center">What people are saying</h2>
          <div className="space-y-8">
            <div className="bg-white dark:bg-gray-800 p-6 rounded shadow">
              <p className="italic">"Platformsify saved us weeks of setup — everything just works out of the box."</p>
              <p className="mt-4 font-bold text-right">— Jane Doe, Startup Founder</p>
            </div>
            <div className="bg-white dark:bg-gray-800 p-6 rounded shadow">
              <p className="italic">"Beautiful UI, fast performance, and solid structure."</p>
              <p className="mt-4 font-bold text-right">— John Smith, DevOps Engineer</p>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}