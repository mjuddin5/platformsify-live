'use client';
import Link from 'next/link';
import { useTheme } from 'next-themes';
import { useEffect, useState } from 'react';

export default function Navbar() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <nav className="bg-white dark:bg-gray-800 shadow-md py-4 px-6 flex justify-between items-center">
      <div className="text-xl font-bold text-blue-600 dark:text-blue-400">Platformsify</div>
      <div className="flex items-center space-x-4">
        <Link href="/" className="hover:text-blue-500 dark:hover:text-blue-300">Home</Link>
        <Link href="/about" className="hover:text-blue-500 dark:hover:text-blue-300">About</Link>
        <Link href="/services" className="hover:text-blue-500 dark:hover:text-blue-300">Services</Link>
        <Link href="/contact" className="hover:text-blue-500 dark:hover:text-blue-300">Contact</Link>
        {mounted && (
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="ml-4 px-3 py-1 rounded bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200"
          >
            {theme === 'dark' ? 'Light' : 'Dark'}
          </button>
        )}
      </div>
    </nav>
  );
}